Contributors
============

This plugin has mostly been developed by [Bastiaan Olij](https://github.com/BastiaanOlij). 
Special thanks to [Benedikt](https://github.com/beniwtv) for doing all the work on overlay support.

Other people who have helped out by submitting fixes, enhancements, etc are:
- [RMKD](https://github.com/RMKD)
- [Bruvzg](https://github.com/bruvzg)
